from scrapy import cmdline
#cmdline.execute(["scrapy","crawl","novel"])
cmdline.execute(["scrapy","crawl","t"])