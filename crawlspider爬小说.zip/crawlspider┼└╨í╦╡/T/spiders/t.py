# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from T.items import TItem

class TSpider(CrawlSpider):
    name = 't'
    allowed_domains = ['xrmn5.cc']
    start_urls = ['https://www.xrmn5.cc']

    rules = (
        Rule(LinkExtractor(allow=r'.*?/.*?/\d+/\d+.html'),callback='parse_item',follow=True),
        Rule(LinkExtractor(allow=r'.*?/.*?/\d+/\d+_\d+.html'),callback='parse_item',follow=True),
    )

    def parse_item(self, response):
        title = response.xpath('//div/h1/text()').get()
        title_urls = response.url
        img_src = ['https://www.xrmn5.cc'+i for i in response.xpath('//div[@class="content_left"]/p/img/@src').getall()]
        item = TItem(title=title,title_urls=title_urls,img_src=img_src)
        return item
